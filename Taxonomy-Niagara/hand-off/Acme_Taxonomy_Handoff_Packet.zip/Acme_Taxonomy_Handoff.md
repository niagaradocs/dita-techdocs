
# Acme Taxonomy Handoff Packet (Canonical Terms + Governance + docKey Rules)

## 1. docKey Governance Rules
docKey is a stable, version-aware identifier uniquely assigned to each documentation asset.
It ensures consistency across CCMS, source control, taxonomy workbook, and crosswalk tables.

### docKey Requirements
1. docKey must remain stable even if document titles change.
2. docKey must be globally unique across all documentation.
3. docKey includes a version suffix (v01, v02...).
4. docKey must align with Documentation Taxonomy category codes.
5. docKey should use lowercase hyphens and no spaces.
6. Only increment version for meaningful updates (new features, rewritten sections, major edits).
7. docKey must be stored in the Documentation Taxonomy and used consistently across systems.

---

## 2. Canonical Terms Tab Structure (Excel Columns)
Use these Excel columns to manage enterprise terminology alignment:

Preferred Term | Synonyms / Variants | Definition | Category | Applies To (Scope) | Used In Docs? | Used In UI? | Notes | Status | Owner

---

## 3. Canonical Terms v1.0 (Starter Set)

### Product-Level Terms
Preferred Term | Synonyms | Definition | Category | Applies To (Scope) | Used In Docs? | Used In UI? | Notes | Status | Owner
--- | --- | --- | --- | --- | --- | --- | --- | --- | ---
Core Controller | controller; edge controller; field device | Hardware device executing automation logic. | Product | Controllers Portfolio | Yes | Yes | None | Approved | Engineering
Cloud Suite | cloud platform; enterprise cloud | Cloud-based services for dashboards, analytics, remote access. | Product | Cloud Services | Yes | No | None | Approved | Product Marketing
Integration Driver | protocol driver; device driver | Module enabling communication with external systems. | Product | Supervisor & Edge | Yes | Yes | None | Approved | Engineering

### Feature-Level Terms
Preferred Term | Synonyms | Definition | Category | Applies To | Docs? | UI? | Notes | Status | Owner
--- | --- | --- | --- | --- | --- | --- | --- | --- | ---
Alarm Routing | alarm forwarding; notify alarm | Defines how alarms reach users or systems. | Feature | Supervisor, Cloud | Yes | Yes | None | Approved | Engineering
Device Discovery | auto-discovery; network scan | Mechanism for detecting devices on a network. | Feature | Controllers, Drivers | Yes | Yes | None | Approved | Engineering
Trend Logging | trending logs; history | Time-series data recording for analytics. | Feature | Supervisor, Cloud | Yes | Yes | None | Approved | Engineering
User Roles | permissions; RBAC | Access control structure for users. | Feature | All Platforms | Yes | Yes | None | Approved | Product Marketing

### Document-Level Terms
Preferred Term | Synonyms | Definition | Category | Applies To | Docs? | UI? | Notes | Status | Owner
--- | --- | --- | --- | --- | --- | --- | --- | --- | ---
Configuration Guide | config guide; setup guide | Describes product configuration procedures. | Document | All Products | Yes | No | Core docType | Approved | Tech Docs
Reference Manual | reference; technical reference | Deep-dive functional reference documentation. | Document | All Products | Yes | No | None | Approved | Tech Docs
Installation Guide | install guide; hardware setup | Instructions for physical installation. | Document | Controllers | Yes | No | None | Approved | Tech Docs

### Crosswalk-Friendly Terms
Preferred Term | Synonyms | Definition | Category | Applies To | Docs? | UI? | Notes | Status | Owner
--- | --- | --- | --- | --- | --- | --- | --- | --- | ---
Product Family | product line; series | Related products grouped by brand or functionality. | Concept | All Products | Yes | No | Important for Finance mapping | Approved | Product Marketing
SKU Mapping | sku; partnumber | Mapping between SKU numbers and taxonomy categories. | Concept | All Products | Yes | No | Finance alignment | Proposed | Finance
Release Version | software version; firmware version | Identifies software/build version used by docs. | Concept | All Products | Yes | Yes | Needed for docKey | Approved | Engineering

---

## 4. Governance Text (Workbook ReadMe)

### Governance Overview
The Acme Enterprise Taxonomy is maintained by Technical Documentation with required participation from Product Marketing and Engineering. Changes must follow a controlled submission and review workflow.

### Roles
- Taxonomy Steward (Tech Docs): Maintains workbook, reviews proposed changes, ensures consistency.
- Engineering SMEs: Validate technical accuracy for product/feature terms.
- Product Marketing: Ensures alignment with external messaging.
- Documentation Team: Applies taxonomy classifications and docKeys.

### Change Workflow
1. Submit a Term or Category Change Request.
2. Steward reviews for duplication and impact.
3. SME and Product Marketing review.
4. Steward updates workbook.
5. Version updated in Release Notes.

### Annual Review
The taxonomy must be reviewed yearly for:
- New products
- Retired terms
- Required structural updates
- Search optimization impacts

---

## 5. Crosswalk Starter Guidance

A crosswalk table maps:
- Product Taxonomy → Documentation Taxonomy
- Product Taxonomy → Controlled Vocabulary
- Finance Naming → Preferred Terms

### Crosswalk Columns
Source Term | Preferred Term | Synonyms | Product Category | Documentation Category | Feature Tags | Notes

### Crosswalk Rules
1. Every source term must map to exactly one Preferred Term.
2. Deprecated terms remain listed for backward compatibility.
3. Use multiple rows if one legacy term maps to multiple preferred categories.
4. Crosswalks must be version-controlled and steward-approved.

---

## 6. Copilot Initialization Message

```
Copilot, load the “00_Project_HandOff” folder and use all documents as grounding context.
My master handoff file is “Acme_Taxonomy_Handoff.md”.
Use the Canonical Terms table, docKey rules, governance text, and crosswalk structure to answer questions, validate terms, and propose taxonomy updates.
Acknowledge once ready and summarize what you understand about the taxonomy.
```

---

## 7. Summary
This handoff packet includes:
- docKey governance rules
- Canonical Terms structure
- Starter Canonical Term set
- Governance text
- Crosswalk starter guidance
- Copilot grounding instructions

Place this file and the DOCX version inside **00_Project_HandOff** for Copilot readiness.
